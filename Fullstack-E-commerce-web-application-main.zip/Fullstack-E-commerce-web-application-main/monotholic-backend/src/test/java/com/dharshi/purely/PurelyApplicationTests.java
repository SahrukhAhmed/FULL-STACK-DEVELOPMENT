package com.dharshi.purely;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PurelyApplicationTests {

	@Test
	void contextLoads() {
	}

}
