package com.dharshi.purely;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PurelyApplication {

	public static void main(String[] args) {
		SpringApplication.run(PurelyApplication.class, args);
	}

}
