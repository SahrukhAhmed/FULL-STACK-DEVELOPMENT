package com.dharshi.purely.enums;

public enum EOrderPaymentStatus {
    PAID,
    UNPAID
}
