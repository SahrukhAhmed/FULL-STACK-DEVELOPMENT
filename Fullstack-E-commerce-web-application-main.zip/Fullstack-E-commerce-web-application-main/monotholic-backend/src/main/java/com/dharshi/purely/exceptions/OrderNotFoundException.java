package com.dharshi.purely.exceptions;

public class OrderNotFoundException extends Exception {
    public OrderNotFoundException(String s) {
        super(s);
    }
}
