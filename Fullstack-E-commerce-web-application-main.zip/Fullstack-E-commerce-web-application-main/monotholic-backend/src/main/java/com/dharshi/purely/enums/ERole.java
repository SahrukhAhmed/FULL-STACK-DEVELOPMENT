package com.dharshi.purely.enums;


public enum ERole {
    ROLE_USER,
    ROLE_ADMIN
}
