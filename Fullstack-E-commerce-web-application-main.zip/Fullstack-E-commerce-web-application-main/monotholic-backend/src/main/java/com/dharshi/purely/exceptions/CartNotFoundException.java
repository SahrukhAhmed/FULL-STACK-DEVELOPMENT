package com.dharshi.purely.exceptions;

public class CartNotFoundException extends Exception{
    public CartNotFoundException(String message) {
        super(message);
    }
}
