package com.dharshi.orderservice.enums;

public enum EOrderPaymentStatus {
    PAID,
    UNPAID
}
