package com.dharshi.authservice.enums;


public enum ERole {
    ROLE_USER,
    ROLE_ADMIN
}
